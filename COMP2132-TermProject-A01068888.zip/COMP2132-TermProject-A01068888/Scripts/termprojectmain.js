let scores, roundScore, activePlayer, dice, gamePlaying, roundNumber;


init();

document.querySelector('.btn-roll').addEventListener('click', function() {
    if (gamePlaying) {
        let dice1 = Math.floor(Math.random() * 6) + 1;
        let dice2 = Math.floor(Math.random() * 6) + 1;

        document.getElementById('dice-1').style.display = 'block';
        document.getElementById('dice-2').style.display = 'block';
        document.getElementById('dice-1').src = `Images/dice-` + (dice1) + `.png`;
        document.getElementById('dice-2').src = `Images/dice-` + (dice2) + `.png`;
        document.getElementById('dice-1').style.animation = 'shake 0.3s';
        document.getElementById('dice-2').style.animation = 'shake 0.3s';
 
        if (dice1 !== 1 && dice2 !==1) {
            //add score
            roundScore += dice1+dice2;
        }
        if (dice1 == dice2) {
            roundScore += roundScore;
        }
        document.getElementById('current-0').textContent = roundScore;
        hold();
        setTimeout(cpuroll, 1000);
    }

});

function cpuroll(){
    if (gamePlaying) {
        let dice1 = Math.floor(Math.random() * 6) + 1;
        let dice2 = Math.floor(Math.random() * 6) + 1;

        document.getElementById('dice-1').style.display = 'block';
        document.getElementById('dice-2').style.display = 'block';
        document.getElementById('dice-1').src = `Images/dice-` + (dice1) + `.png`;
        document.getElementById('dice-2').src = `Images/dice-` + (dice2) + `.png`;
        document.getElementById('dice-1').style.animation = 'shake 0.3s';
        document.getElementById('dice-2').style.animation = 'shake 0.3s';

        if (dice1 !== 1 && dice2 !==1) {
            //add score
            roundScore += dice1+dice2;
        }
        if (dice1 == dice2) {
            roundScore += roundScore;
        }
        
        document.getElementById('current-1').textContent = roundScore;
        setTimeout(hold, 750);
        roundNumber++;
    }

}

function hold(){
    if (gamePlaying) {
        scores[activePlayer] += roundScore;
        document.querySelector('#score-' + activePlayer).textContent = scores[activePlayer];

        let input = document.querySelector('.final-score').value;

        if (activePlayer === 1 && roundNumber == 3) {
            if(scores[0] > scores[1]){
                activePlayer = 0;
            }
            document.querySelector('#name-' + activePlayer).textContent = 'Winner!';
            document.getElementById('dice-1').style.display = 'none';
            document.getElementById('dice-2').style.display = 'none';
            document.querySelector('.player-' + activePlayer + '-panel').classList.add('winner');
            document.querySelector('.player-' + activePlayer + '-panel').classList.remove('active');
            gamePlaying = false;
        } else {
            //next player
            nextPlayer();
        }
    }
}

function nextPlayer() {
    //next player
    activePlayer === 0 ? activePlayer = 1 : activePlayer = 0;
    roundScore = 0;

    //document.querySelector('.player-0-panel').classList.remove('active');
    //document.querySelector('.player-1-panel').classList.add('active');

    document.querySelector('.player-0-panel').classList.toggle('active');
    document.querySelector('.player-1-panel').classList.toggle('active');

    // document.getElementById('dice-1').style.display = 'none';
    // document.getElementById('dice-2').style.display = 'none';
}

document.querySelector('.btn-new').addEventListener('click', init);

function init() {
    scores = [0, 0]
    activePlayer = 0;
    roundScore = 0;
    gamePlaying = true;
    roundNumber = 0;

    document.getElementById('score-0').textContent = '0';
    document.getElementById('score-1').textContent = '0';
    document.querySelector('#name-0').textContent = 'Player';
    document.querySelector('#name-1').textContent = 'CPU';
    document.querySelector('.player-0-panel').classList.remove('winner');
    document.querySelector('.player-1-panel').classList.remove('winner');
    document.querySelector('.player-0-panel').classList.remove('active');
    document.querySelector('.player-1-panel').classList.remove('active');
    document.querySelector('.player-0-panel').classList.add('active');
    document.getElementById('current-0').textContent = '0';
    document.getElementById('current-1').textContent = '0';
}